-- ================================================================
--  HOLZPOLTER GPS — Supabase Schema (idempotent, wiederholbar)
-- ================================================================

-- ── BESTEHENDE POLICIES LÖSCHEN ───────────────────────────────────
drop policy if exists "own company"          on companies;
drop policy if exists "own company profiles" on profiles;
drop policy if exists "own company markers"  on markers;
drop policy if exists "own company tracks"   on tracks;

-- ── TABELLEN ANLEGEN ─────────────────────────────────────────────
create table if not exists companies (
  id         uuid primary key default gen_random_uuid(),
  name       text not null,
  created_at timestamptz default now()
);

create table if not exists profiles (
  id         uuid primary key references auth.users on delete cascade,
  company_id uuid references companies(id) on delete cascade,
  name       text not null,
  role       text not null check (role in ('admin','harvester','forwarder')),
  created_at timestamptz default now()
);

create table if not exists markers (
  id         uuid primary key default gen_random_uuid(),
  company_id uuid references companies(id) on delete cascade not null,
  created_by uuid references profiles(id) on delete set null,
  lat        double precision not null,
  lng        double precision not null,
  typ        text not null check (typ in ('harvester','ruecke','notiz')),
  art        text,
  menge      text,
  notiz      text,
  done       boolean default false,
  auto       boolean default false,
  created_at timestamptz default now()
);

create table if not exists tracks (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid references companies(id) on delete cascade not null,
  created_by  uuid references profiles(id) on delete set null,
  pts         jsonb not null,
  km          text,
  recorded_at text,
  created_at  timestamptz default now()
);

-- ── ROW LEVEL SECURITY ────────────────────────────────────────────
alter table companies enable row level security;
alter table profiles   enable row level security;
alter table markers    enable row level security;
alter table tracks     enable row level security;

-- Companies
create policy "own company" on companies
  for all using (
    id = (select company_id from profiles where id = auth.uid())
  );

-- Profiles
create policy "own company profiles" on profiles
  for all using (
    company_id = (select company_id from profiles where id = auth.uid())
  );

-- Markers
create policy "own company markers" on markers
  for all using (
    company_id = (select company_id from profiles where id = auth.uid())
  );

-- Tracks
create policy "own company tracks" on tracks
  for all using (
    company_id = (select company_id from profiles where id = auth.uid())
  );

-- ── REALTIME AKTIVIEREN ───────────────────────────────────────────
do $$
begin
  alter publication supabase_realtime add table markers;
exception when others then null;
end $$;

do $$
begin
  alter publication supabase_realtime add table tracks;
exception when others then null;
end $$;
